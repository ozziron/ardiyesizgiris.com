"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Plus, Edit, Trash2, Save, X, Ship, Container } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Liman şeması
const limanSchema = z.object({
  value: z.string().min(1, "Liman kodu gereklidir"),
  label: z.string().min(1, "Liman adı gereklidir"),
  ardiyeFreeTime: z.number().min(1, "Ardiye free time en az 1 gün olmalıdır"),
  detentionFreeTime: z.number().min(1, "Detention free time en az 1 gün olmalıdır"),
})

// Konteyner tipi şeması
const konteynerSchema = z.object({
  value: z.string().min(1, "Konteyner kodu gereklidir"),
  label: z.string().min(1, "Konteyner adı gereklidir"),
  multiplier: z.number().min(0.1, "Çarpan en az 0.1 olmalıdır").max(5, "Çarpan en fazla 5 olabilir"),
})

// Varsayılan veriler
const defaultLimanlar = [
  { value: "istanbul", label: "İstanbul Limanı", ardiyeFreeTime: 7, detentionFreeTime: 14 },
  { value: "izmir", label: "İzmir Limanı", ardiyeFreeTime: 5, detentionFreeTime: 10 },
  { value: "mersin", label: "Mersin Limanı", ardiyeFreeTime: 10, detentionFreeTime: 15 },
  { value: "iskenderun", label: "İskenderun Limanı", ardiyeFreeTime: 7, detentionFreeTime: 12 },
  { value: "samsun", label: "Samsun Limanı", ardiyeFreeTime: 6, detentionFreeTime: 11 },
  { value: "tekirdag", label: "Tekirdağ Limanı", ardiyeFreeTime: 8, detentionFreeTime: 13 },
  { value: "antalya", label: "Antalya Limanı", ardiyeFreeTime: 5, detentionFreeTime: 10 },
  { value: "trabzon", label: "Trabzon Limanı", ardiyeFreeTime: 6, detentionFreeTime: 12 },
]

const defaultKonteynerTipleri = [
  { value: "20DC", label: "20' Standart (DC)", multiplier: 1.0 },
  { value: "40DC", label: "40' Standart (DC)", multiplier: 1.0 },
  { value: "40HC", label: "40' Yüksek (HC)", multiplier: 1.0 },
  { value: "20OT", label: "20' Açık Üst (OT)", multiplier: 1.2 },
  { value: "40OT", label: "40' Açık Üst (OT)", multiplier: 1.2 },
  { value: "20FR", label: "20' Flat Rack (FR)", multiplier: 1.3 },
  { value: "40FR", label: "40' Flat Rack (FR)", multiplier: 1.3 },
  { value: "20RF", label: "20' Buzdolabı (RF)", multiplier: 0.8 },
  { value: "40RF", label: "40' Buzdolabı (RF)", multiplier: 0.8 },
]

export function AdminDashboard() {
  const [limanlar, setLimanlar] = useState(defaultLimanlar)
  const [konteynerTipleri, setKonteynerTipleri] = useState(defaultKonteynerTipleri)
  const [editingLiman, setEditingLiman] = useState<any>(null)
  const [editingKonteyner, setEditingKonteyner] = useState<any>(null)
  const [isLimanDialogOpen, setIsLimanDialogOpen] = useState(false)
  const [isKonteynerDialogOpen, setIsKonteynerDialogOpen] = useState(false)

  const limanForm = useForm<z.infer<typeof limanSchema>>({
    resolver: zodResolver(limanSchema),
    defaultValues: {
      value: "",
      label: "",
      ardiyeFreeTime: 7,
      detentionFreeTime: 14,
    },
  })

  const konteynerForm = useForm<z.infer<typeof konteynerSchema>>({
    resolver: zodResolver(konteynerSchema),
    defaultValues: {
      value: "",
      label: "",
      multiplier: 1.0,
    },
  })

  // Liman işlemleri
  function onLimanSubmit(values: z.infer<typeof limanSchema>) {
    if (editingLiman) {
      // Güncelle
      setLimanlar(prev => prev.map(liman => 
        liman.value === editingLiman.value ? values : liman
      ))
    } else {
      // Yeni ekle
      setLimanlar(prev => [...prev, values])
    }
    
    setIsLimanDialogOpen(false)
    setEditingLiman(null)
    limanForm.reset()
  }

  function editLiman(liman: any) {
    setEditingLiman(liman)
    limanForm.reset(liman)
    setIsLimanDialogOpen(true)
  }

  function deleteLiman(value: string) {
    setLimanlar(prev => prev.filter(liman => liman.value !== value))
  }

  // Konteyner işlemleri
  function onKonteynerSubmit(values: z.infer<typeof konteynerSchema>) {
    if (editingKonteyner) {
      // Güncelle
      setKonteynerTipleri(prev => prev.map(konteyner => 
        konteyner.value === editingKonteyner.value ? values : konteyner
      ))
    } else {
      // Yeni ekle
      setKonteynerTipleri(prev => [...prev, values])
    }
    
    setIsKonteynerDialogOpen(false)
    setEditingKonteyner(null)
    konteynerForm.reset()
  }

  function editKonteyner(konteyner: any) {
    setEditingKonteyner(konteyner)
    konteynerForm.reset(konteyner)
    setIsKonteynerDialogOpen(true)
  }

  function deleteKonteyner(value: string) {
    setKonteynerTipleri(prev => prev.filter(konteyner => konteyner.value !== value))
  }

  // Verileri kaydet (localStorage'a)
  function saveData() {
    localStorage.setItem("admin_limanlar", JSON.stringify(limanlar))
    localStorage.setItem("admin_konteyner_tipleri", JSON.stringify(konteynerTipleri))
    alert("Veriler başarıyla kaydedildi!")
  }

  // Verileri yükle
  useEffect(() => {
    const savedLimanlar = localStorage.getItem("admin_limanlar")
    const savedKonteynerTipleri = localStorage.getItem("admin_konteyner_tipleri")
    
    if (savedLimanlar) {
      setLimanlar(JSON.parse(savedLimanlar))
    }
    if (savedKonteynerTipleri) {
      setKonteynerTipleri(JSON.parse(savedKonteynerTipleri))
    }
  }, [])

  return (
    <div className="space-y-6">
      {/* Kaydet butonu */}
      <div className="flex justify-end">
        <Button onClick={saveData} className="gap-2">
          <Save className="h-4 w-4" />
          Değişiklikleri Kaydet
        </Button>
      </div>

      <Alert>
        <AlertDescription>
          Bu panelde yaptığınız değişiklikler hesaplama modülünde kullanılacaktır. 
          Değişiklikleri kaydetmeyi unutmayın.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="limanlar" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="limanlar">Liman Yönetimi</TabsTrigger>
          <TabsTrigger value="konteynerler">Konteyner Tipleri</TabsTrigger>
        </TabsList>

        {/* Liman Yönetimi */}
        <TabsContent value="limanlar" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Ship className="h-5 w-5" />
                    Liman Yönetimi
                  </CardTitle>
                  <CardDescription>
                    Limanları ve free time sürelerini yönetin
                  </CardDescription>
                </div>
                
                <Dialog open={isLimanDialogOpen} onOpenChange={setIsLimanDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => {
                      setEditingLiman(null)
                      limanForm.reset({
                        value: "",
                        label: "",
                        ardiyeFreeTime: 7,
                        detentionFreeTime: 14,
                      })
                    }}>
                      <Plus className="h-4 w-4 mr-2" />
                      Yeni Liman
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {editingLiman ? "Liman Düzenle" : "Yeni Liman Ekle"}
                      </DialogTitle>
                      <DialogDescription>
                        Liman bilgilerini ve free time sürelerini girin
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...limanForm}>
                      <form onSubmit={limanForm.handleSubmit(onLimanSubmit)} className="space-y-4">
                        <FormField
                          control={limanForm.control}
                          name="value"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Liman Kodu</FormLabel>
                              <FormControl>
                                <Input placeholder="istanbul" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={limanForm.control}
                          name="label"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Liman Adı</FormLabel>
                              <FormControl>
                                <Input placeholder="İstanbul Limanı" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={limanForm.control}
                            name="ardiyeFreeTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Ardiye Free Time (gün)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    {...field} 
                                    onChange={e => field.onChange(parseInt(e.target.value))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={limanForm.control}
                            name="detentionFreeTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Detention Free Time (gün)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    {...field} 
                                    onChange={e => field.onChange(parseInt(e.target.value))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="flex justify-end gap-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsLimanDialogOpen(false)}
                          >
                            İptal
                          </Button>
                          <Button type="submit">
                            {editingLiman ? "Güncelle" : "Ekle"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Liman Kodu</TableHead>
                    <TableHead>Liman Adı</TableHead>
                    <TableHead>Ardiye Free Time</TableHead>
                    <TableHead>Detention Free Time</TableHead>
                    <TableHead>İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {limanlar.map((liman) => (
                    <TableRow key={liman.value}>
                      <TableCell>
                        <Badge variant="outline">{liman.value}</Badge>
                      </TableCell>
                      <TableCell>{liman.label}</TableCell>
                      <TableCell>{liman.ardiyeFreeTime} gün</TableCell>
                      <TableCell>{liman.detentionFreeTime} gün</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => editLiman(liman)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => deleteLiman(liman.value)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Konteyner Tipleri */}
        <TabsContent value="konteynerler" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Container className="h-5 w-5" />
                    Konteyner Tipleri
                  </CardTitle>
                  <CardDescription>
                    Konteyner tiplerini ve çarpanlarını yönetin
                  </CardDescription>
                </div>
                
                <Dialog open={isKonteynerDialogOpen} onOpenChange={setIsKonteynerDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => {
                      setEditingKonteyner(null)
                      konteynerForm.reset({
                        value: "",
                        label: "",
                        multiplier: 1.0,
                      })
                    }}>
                      <Plus className="h-4 w-4 mr-2" />
                      Yeni Konteyner Tipi
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {editingKonteyner ? "Konteyner Tipi Düzenle" : "Yeni Konteyner Tipi Ekle"}
                      </DialogTitle>
                      <DialogDescription>
                        Konteyner tipi bilgilerini girin
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...konteynerForm}>
                      <form onSubmit={konteynerForm.handleSubmit(onKonteynerSubmit)} className="space-y-4">
                        <FormField
                          control={konteynerForm.control}
                          name="value"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Konteyner Kodu</FormLabel>
                              <FormControl>
                                <Input placeholder="20DC" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={konteynerForm.control}
                          name="label"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Konteyner Adı</FormLabel>
                              <FormControl>
                                <Input placeholder="20' Standart (DC)" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={konteynerForm.control}
                          name="multiplier"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Çarpan (0.1 - 5.0)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.1"
                                  min="0.1"
                                  max="5.0"
                                  {...field} 
                                  onChange={e => field.onChange(parseFloat(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end gap-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsKonteynerDialogOpen(false)}
                          >
                            İptal
                          </Button>
                          <Button type="submit">
                            {editingKonteyner ? "Güncelle" : "Ekle"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Konteyner Kodu</TableHead>
                    <TableHead>Konteyner Adı</TableHead>
                    <TableHead>Çarpan</TableHead>
                    <TableHead>İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {konteynerTipleri.map((konteyner) => (
                    <TableRow key={konteyner.value}>
                      <TableCell>
                        <Badge variant="outline">{konteyner.value}</Badge>
                      </TableCell>
                      <TableCell>{konteyner.label}</TableCell>
                      <TableCell>x{konteyner.multiplier}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => editKonteyner(konteyner)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => deleteKonteyner(konteyner.value)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}