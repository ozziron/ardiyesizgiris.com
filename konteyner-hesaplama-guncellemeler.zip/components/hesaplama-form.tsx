"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { format } from "date-fns"
import { tr } from "date-fns/locale"
import { CalendarIcon, Ship, Loader2, Calculator } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Ardiye hesaplama formu şeması
const ardiyeFormSchema = z.object({
  liman: z.string({
    required_error: "Lütfen bir liman seçin.",
  }),
  konteynerTipi: z.string({
    required_error: "Lütfen konteyner tipini seçin.",
  }),
  gateOutTarihi: z.date({
    required_error: "Lütfen gate out tarihini seçin.",
  }),
  gateInTarihi: z.date().optional(),
  ihracatMi: z.boolean().default(false).optional(),
  tehlikeliYukMu: z.boolean().default(false).optional(),
})

// Detention hesaplama formu şeması
const detentionFormSchema = z.object({
  liman: z.string({
    required_error: "Lütfen bir liman seçin.",
  }),
  konteynerTipi: z.string({
    required_error: "Lütfen konteyner tipini seçin.",
  }),
  gateOutTarihi: z.date({
    required_error: "Lütfen gate out tarihini seçin.",
  }),
  gateInTarihi: z.date().optional(),
  ihracatMi: z.boolean().default(false).optional(),
  tehlikeliYukMu: z.boolean().default(false).optional(),
})

// Varsayılan veriler (admin paneli yoksa kullanılacak)
const defaultLimanlar = [
  { value: "istanbul", label: "İstanbul Limanı", ardiyeFreeTime: 7, detentionFreeTime: 14 },
  { value: "izmir", label: "İzmir Limanı", ardiyeFreeTime: 5, detentionFreeTime: 10 },
  { value: "mersin", label: "Mersin Limanı", ardiyeFreeTime: 10, detentionFreeTime: 15 },
  { value: "iskenderun", label: "İskenderun Limanı", ardiyeFreeTime: 7, detentionFreeTime: 12 },
  { value: "samsun", label: "Samsun Limanı", ardiyeFreeTime: 6, detentionFreeTime: 11 },
  { value: "tekirdag", label: "Tekirdağ Limanı", ardiyeFreeTime: 8, detentionFreeTime: 13 },
  { value: "antalya", label: "Antalya Limanı", ardiyeFreeTime: 5, detentionFreeTime: 10 },
  { value: "trabzon", label: "Trabzon Limanı", ardiyeFreeTime: 6, detentionFreeTime: 12 },
]

const defaultKonteynerTipleri = [
  { value: "20DC", label: "20' Standart (DC)", multiplier: 1.0 },
  { value: "40DC", label: "40' Standart (DC)", multiplier: 1.0 },
  { value: "40HC", label: "40' Yüksek (HC)", multiplier: 1.0 },
  { value: "20OT", label: "20' Açık Üst (OT)", multiplier: 1.2 },
  { value: "40OT", label: "40' Açık Üst (OT)", multiplier: 1.2 },
  { value: "20FR", label: "20' Flat Rack (FR)", multiplier: 1.3 },
  { value: "40FR", label: "40' Flat Rack (FR)", multiplier: 1.3 },
  { value: "20RF", label: "20' Buzdolabı (RF)", multiplier: 0.8 },
  { value: "40RF", label: "40' Buzdolabı (RF)", multiplier: 0.8 },
]

// İş günü hesaplama fonksiyonu
function addBusinessDays(date: Date, days: number): Date {
  const result = new Date(date)
  let addedDays = 0
  
  while (addedDays < Math.abs(days)) {
    if (days > 0) {
      result.setDate(result.getDate() + 1)
    } else {
      result.setDate(result.getDate() - 1)
    }
    // Hafta sonu kontrolü (0 = Pazar, 6 = Cumartesi)
    if (result.getDay() !== 0 && result.getDay() !== 6) {
      addedDays++
    }
  }
  
  return result
}

// Gün farkı hesaplama fonksiyonu
function getBusinessDaysDifference(startDate: Date, endDate: Date): number {
  let days = 0
  const current = new Date(startDate)
  
  while (current < endDate) {
    current.setDate(current.getDate() + 1)
    if (current.getDay() !== 0 && current.getDay() !== 6) {
      days++
    }
  }
  
  return days
}

export function HesaplamaForm() {
  const [activeTab, setActiveTab] = useState("ardiye")
  const [isCalculating, setIsCalculating] = useState(false)
  const [limanlar, setLimanlar] = useState(defaultLimanlar)
  const [konteynerTipleri, setKonteynerTipleri] = useState(defaultKonteynerTipleri)
  const [result, setResult] = useState<{
    ardiyesizGirisTarihi: Date | null
    kalanGun: number | null
    ardiyeGunSayisi: number | null
    detaylar: string | null
  } | null>(null)

  // Admin panelinden verileri yükle
  useEffect(() => {
    const savedLimanlar = localStorage.getItem("admin_limanlar")
    const savedKonteynerTipleri = localStorage.getItem("admin_konteyner_tipleri")
    
    if (savedLimanlar) {
      try {
        setLimanlar(JSON.parse(savedLimanlar))
      } catch (e) {
        console.error("Liman verileri yüklenemedi:", e)
      }
    }
    
    if (savedKonteynerTipleri) {
      try {
        setKonteynerTipleri(JSON.parse(savedKonteynerTipleri))
      } catch (e) {
        console.error("Konteyner tipi verileri yüklenemedi:", e)
      }
    }
  }, [])

  const ardiyeForm = useForm<z.infer<typeof ardiyeFormSchema>>({
    resolver: zodResolver(ardiyeFormSchema),
    defaultValues: {
      ihracatMi: false,
      tehlikeliYukMu: false,
    },
  })

  const detentionForm = useForm<z.infer<typeof detentionFormSchema>>({
    resolver: zodResolver(detentionFormSchema),
    defaultValues: {
      ihracatMi: false,
      tehlikeliYukMu: false,
    },
  })

  function onArdiyeSubmit(values: z.infer<typeof ardiyeFormSchema>) {
    setIsCalculating(true)

    setTimeout(() => {
      const gateOutTarihi = new Date(values.gateOutTarihi)
      const gateInTarihi = values.gateInTarihi ? new Date(values.gateInTarihi) : null

      // Liman bilgilerini bul
      const liman = limanlar.find(l => l.value === values.liman)
      if (!liman) {
        setIsCalculating(false)
        return
      }

      // Free time süresini hesapla
      let freeTimeSuresi = liman.ardiyeFreeTime

      // Konteyner tipi çarpanı
      const konteynerTipi = konteynerTipleri.find(k => k.value === values.konteynerTipi)
      if (konteynerTipi) {
        freeTimeSuresi = Math.round(freeTimeSuresi * konteynerTipi.multiplier)
      }

      // İhracat ve tehlikeli yük ayarlamaları
      if (values.ihracatMi) freeTimeSuresi += 2
      if (values.tehlikeliYukMu) freeTimeSuresi -= 1

      // Gate out tarihinden geriye doğru hesapla
      const ardiyesizGirisTarihi = addBusinessDays(gateOutTarihi, -freeTimeSuresi)

      let ardiyeGunSayisi = null
      if (gateInTarihi) {
        // Gate in tarihi varsa ardiye gün sayısını hesapla
        if (gateInTarihi <= ardiyesizGirisTarihi) {
          ardiyeGunSayisi = 0 // Ardiyesiz giriş yapmış
        } else {
          ardiyeGunSayisi = getBusinessDaysDifference(ardiyesizGirisTarihi, gateInTarihi)
        }
      }

      // Bugünden ardiyesiz giriş tarihine kalan gün
      const bugun = new Date()
      const kalanGun = Math.ceil((ardiyesizGirisTarihi.getTime() - bugun.getTime()) / (1000 * 60 * 60 * 24))

      setResult({
        ardiyesizGirisTarihi,
        kalanGun,
        ardiyeGunSayisi,
        detaylar: `${liman.label} için ardiye free time süresi ${freeTimeSuresi} iş günüdür.`,
      })

      setIsCalculating(false)
    }, 1500)
  }

  function onDetentionSubmit(values: z.infer<typeof detentionFormSchema>) {
    setIsCalculating(true)

    setTimeout(() => {
      const gateOutTarihi = new Date(values.gateOutTarihi)
      const gateInTarihi = values.gateInTarihi ? new Date(values.gateInTarihi) : null

      // Liman bilgilerini bul
      const liman = limanlar.find(l => l.value === values.liman)
      if (!liman) {
        setIsCalculating(false)
        return
      }

      // Free time süresini hesapla
      let freeTimeSuresi = liman.detentionFreeTime

      // Konteyner tipi çarpanı
      const konteynerTipi = konteynerTipleri.find(k => k.value === values.konteynerTipi)
      if (konteynerTipi) {
        freeTimeSuresi = Math.round(freeTimeSuresi * konteynerTipi.multiplier)
      }

      // İhracat ve tehlikeli yük ayarlamaları
      if (values.ihracatMi) freeTimeSuresi += 3
      if (values.tehlikeliYukMu) freeTimeSuresi -= 2

      // Gate out tarihinden geriye doğru hesapla
      const ardiyesizGirisTarihi = addBusinessDays(gateOutTarihi, -freeTimeSuresi)

      let ardiyeGunSayisi = null
      if (gateInTarihi) {
        // Gate in tarihi varsa detention gün sayısını hesapla
        if (gateInTarihi <= ardiyesizGirisTarihi) {
          ardiyeGunSayisi = 0 // Ücretsiz giriş yapmış
        } else {
          ardiyeGunSayisi = getBusinessDaysDifference(ardiyesizGirisTarihi, gateInTarihi)
        }
      }

      // Bugünden ücretsiz giriş tarihine kalan gün
      const bugun = new Date()
      const kalanGun = Math.ceil((ardiyesizGirisTarihi.getTime() - bugun.getTime()) / (1000 * 60 * 60 * 24))

      setResult({
        ardiyesizGirisTarihi,
        kalanGun,
        ardiyeGunSayisi,
        detaylar: `${liman.label} için detention free time süresi ${freeTimeSuresi} iş günüdür.`,
      })

      setIsCalculating(false)
    }, 1500)
  }

  const renderForm = (formType: "ardiye" | "detention") => {
    const form = formType === "ardiye" ? ardiyeForm : detentionForm
    const onSubmit = formType === "ardiye" ? onArdiyeSubmit : onDetentionSubmit

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="liman"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Liman</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Liman seçin" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {limanlar.map((liman) => (
                        <SelectItem key={liman.value} value={liman.value}>
                          {liman.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>İşlem yapacağınız limanı seçin.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="konteynerTipi"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Konteyner Tipi</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Konteyner tipi seçin" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {konteynerTipleri.map((tip) => (
                        <SelectItem key={tip.value} value={tip.value}>
                          {tip.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>Konteyner tipini seçin.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="gateOutTarihi"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Gate Out Tarihi</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                        >
                          {field.value ? format(field.value, "PPP", { locale: tr }) : <span>Tarih seçin</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date < new Date("1900-01-01")}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>Geminin limandan çıkış tarihini seçin.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="gateInTarihi"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Gate In Tarihi (Opsiyonel)</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                        >
                          {field.value ? format(field.value, "PPP", { locale: tr }) : <span>Tarih seçin (opsiyonel)</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date < new Date("1900-01-01")}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>Konteyner giriş tarihi (masraf hesabı için).</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="ihracatMi"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>İhracat Yükü</FormLabel>
                    <FormDescription>Bu bir ihracat yükü ise işaretleyin.</FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="tehlikeliYukMu"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Tehlikeli Yük</FormLabel>
                    <FormDescription>Bu bir tehlikeli yük ise işaretleyin.</FormDescription>
                  </div>
                </FormItem>
              )}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isCalculating}>
            {isCalculating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Hesaplanıyor
              </>
            ) : (
              <>
                <Calculator className="mr-2 h-4 w-4" />
                {formType === "ardiye" ? "Ardiye Hesapla" : "Detention Hesapla"}
              </>
            )}
          </Button>
        </form>
      </Form>
    )
  }

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="ardiye">Ardiye Hesaplama</TabsTrigger>
          <TabsTrigger value="detention">Detention Hesaplama</TabsTrigger>
        </TabsList>
        
        <TabsContent value="ardiye" className="space-y-6">
          {renderForm("ardiye")}
        </TabsContent>
        
        <TabsContent value="detention" className="space-y-6">
          {renderForm("detention")}
        </TabsContent>
      </Tabs>

      {result && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Hesaplama Sonucu</span>
              <Badge variant={result.kalanGun && result.kalanGun > 0 ? "outline" : "destructive"}>
                {result.kalanGun && result.kalanGun > 0 ? `${result.kalanGun} gün kaldı` : "Süre doldu"}
              </Badge>
            </CardTitle>
            <CardDescription>{result.detaylar}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {activeTab === "ardiye" ? "Ardiyesiz Giriş Tarihi" : "Ücretsiz Giriş Tarihi"}
                  </p>
                  <p className="text-lg font-semibold">
                    {result.ardiyesizGirisTarihi
                      ? format(result.ardiyesizGirisTarihi, "PPP", { locale: tr })
                      : "Hesaplanamadı"}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Kalan Gün</p>
                  <p className="text-lg font-semibold">
                    {result.kalanGun !== null ? `${result.kalanGun} gün` : "Hesaplanamadı"}
                  </p>
                </div>
              </div>

              {result.ardiyeGunSayisi !== null && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {activeTab === "ardiye" ? "Ardiye Gün Sayısı" : "Detention Gün Sayısı"}
                  </p>
                  <p className="text-lg font-semibold text-red-600">
                    {result.ardiyeGunSayisi} gün
                  </p>
                </div>
              )}

              <Alert>
                <Ship className="h-4 w-4" />
                <AlertTitle>Bilgilendirme</AlertTitle>
                <AlertDescription>
                  Bu hesaplama tahmini bir değerdir. Kesin bilgi için liman yetkililerine danışınız.
                  Hesaplama iş günleri bazında yapılmıştır (hafta sonları hariç).
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setResult(null)}>
              Yeni Hesaplama
            </Button>
            <Button variant="secondary">Sonucu Kaydet</Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}