# Konteyner Hesaplama Sistemi - Güncellemeler

## Yapılan Değişiklikler

### 1. Hesaplama Modülü Güncellemeleri ✅
- **Konteyner ID alanı kaldırıldı** - Artık ekipman bilgisi olmadan hesaplama yapılabilir
- **İki tab sistemi eklendi:**
  - Ardiye Hesaplama
  - Detention Hesaplama
- **Gate Out tarihi ana parametre oldu** - Doğru hesaplama mantığı
- **Gate In tarihi opsiyonel** - Masraf hesabı için kullanılıyor
- **Doğru hesaplama algoritması:**
  - Gate out tarihinden geriye doğru hesaplama
  - İş günü bazında hesaplama (hafta sonları hariç)
  - Konteyner tipi çarpanları
  - İhracat/tehlikeli yük ayarlamaları

### 2. Admin Paneli Sistemi ✅
- **Admin giriş sayfası:** `/admin/login`
  - Kullanıcı adı: `admin`
  - Şifre: `admin123`
- **Admin dashboard:** `/admin`
  - Liman yönetimi (ekleme/düzenleme/silme)
  - Konteyner tipi yönetimi
  - Free time sürelerini ayarlama
  - Konteyner tipi çarpanlarını ayarlama
- **Veri yönetimi:**
  - localStorage ile veri saklama
  - Hesaplama modülü ile otomatik entegrasyon

### 3. Teknik İyileştirmeler ✅
- **İş günü hesaplama fonksiyonları**
- **Hata yönetimi ve validasyon**
- **Admin verilerinin otomatik yüklenmesi**
- **Responsive tasarım korundu**
- **Mevcut UI/UX tasarımı korundu**

## Kullanım Kılavuzu

### Normal Kullanıcılar İçin:
1. `/hesaplama` sayfasına gidin
2. Ardiye veya Detention tabını seçin
3. Liman ve konteyner tipini seçin
4. Gate out tarihini girin (zorunlu)
5. Gate in tarihini girin (opsiyonel - masraf hesabı için)
6. İhracat/tehlikeli yük seçeneklerini işaretleyin
7. Hesapla butonuna tıklayın

### Admin Kullanıcıları İçin:
1. `/admin/login` sayfasına gidin
2. Kullanıcı adı: `admin`, Şifre: `admin123`
3. Liman yönetimi tabında:
   - Yeni liman ekleyin
   - Mevcut limanları düzenleyin
   - Ardiye ve detention free time sürelerini ayarlayın
4. Konteyner tipleri tabında:
   - Yeni konteyner tipleri ekleyin
   - Çarpan değerlerini ayarlayın
5. "Değişiklikleri Kaydet" butonuna tıklayın

## Hesaplama Mantığı

### Ardiye Hesaplama:
1. Liman ardiye free time süresi alınır
2. Konteyner tipi çarpanı uygulanır
3. İhracat yükü ise +2 gün eklenir
4. Tehlikeli yük ise -1 gün çıkarılır
5. Gate out tarihinden geriye doğru iş günü sayılır
6. Gate in tarihi varsa masraf günü hesaplanır

### Detention Hesaplama:
1. Liman detention free time süresi alınır
2. Konteyner tipi çarpanı uygulanır
3. İhracat yükü ise +3 gün eklenir
4. Tehlikeli yük ise -2 gün çıkarılır
5. Gate out tarihinden geriye doğru iş günü sayılır
6. Gate in tarihi varsa masraf günü hesaplanır

## Dosya Yapısı

### Yeni Eklenen Dosyalar:
- `app/admin/page.tsx` - Admin ana sayfası
- `app/admin/login/page.tsx` - Admin giriş sayfası
- `components/admin-dashboard.tsx` - Admin dashboard bileşeni
- `components/admin-login-form.tsx` - Admin giriş formu

### Güncellenen Dosyalar:
- `components/hesaplama-form.tsx` - Hesaplama modülü
- `components/layout/header.tsx` - Admin linki eklendi

## Güvenlik Notları

⚠️ **Önemli:** Mevcut admin sistemi demo amaçlıdır. Üretim ortamında:
- JWT token sistemi kullanın
- Şifreler hash'lenmelidir
- API endpoint'leri güvenli hale getirilmelidir
- HTTPS kullanın
- Rate limiting ekleyin

## Gelecek Geliştirmeler

1. **Veritabanı entegrasyonu** (PostgreSQL/MySQL)
2. **Gerçek authentication sistemi**
3. **API endpoint'leri**
4. **Kullanıcı rolleri ve yetkileri**
5. **Hesaplama geçmişi**
6. **PDF rapor oluşturma**
7. **Email bildirimleri**
8. **Mobil uygulama**

## Test Senaryoları

### Hesaplama Testi:
- Gate out: 15 Ocak 2025
- Liman: İstanbul (7 gün ardiye free time)
- Konteyner: 20DC (1.0 çarpan)
- Beklenen ardiyesiz giriş: 6 Ocak 2025 (iş günü bazında)

### Admin Panel Testi:
1. Admin girişi yapın
2. Yeni liman ekleyin
3. Free time sürelerini değiştirin
4. Değişiklikleri kaydedin
5. Hesaplama sayfasında yeni değerlerin görünüp görünmediğini kontrol edin
