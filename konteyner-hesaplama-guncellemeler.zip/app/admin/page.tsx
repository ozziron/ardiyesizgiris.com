import { redirect } from "next/navigation"
import { AdminDashboard } from "@/components/admin-dashboard"

export const metadata = {
  title: "Admin Panel | Liman Yönetimi",
  description: "Liman ve konteyner verilerini yönetin",
}

// Basit auth kontrolü - gerçek uygulamada JWT/session kullanın
function checkAuth() {
  // Bu kısım gerçek auth sistemi ile değiştirilecek
  return true
}

export default function AdminPage() {
  if (!checkAuth()) {
    redirect("/admin/login")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Liman bilgileri, konteyner tipleri ve free time sürelerini yönetin
        </p>
      </div>
      
      <AdminDashboard />
    </div>
  )
}